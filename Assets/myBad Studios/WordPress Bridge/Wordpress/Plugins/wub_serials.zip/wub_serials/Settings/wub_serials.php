<?php

function show_wub_serials_content()
{

    if ( !current_user_can( 'manage_wub' ) )
    {
        return __('You do not have sufficient permissions to access this page.');
        wp_die('');
    }

    $output = '<h2>Serial management</h2>';

	define('MENUSUB', (Posted('menu_sub') == '' ? 'Overview' : Posted('menu_sub')) );

    //See what game we are working with
    $gid = Postedi("gid");

    //first determine if there are more than 1 game id
    $games = new WubGames();
    if ( $games->GameCount() == 0)
    {
        $output .= '<div class=error><pre>No game data found...</pre></div>';
        return $output;
    }

    //make sure we are dealing with a game, at least...
    if ($gid == 0)
        $gid = $games->GetFirstGameID();

    $games_dropdown = '<form method=post style="width:220px">'
	    . '<input type=hidden name="menu_tab" value="' . MENUTAB . '">'
	    . '<input type=hidden name="menu_sub" value="' . MENUSUB . '">'
        . $games->GamesDropDownList($gid, false, "gid", "", '','submit')
        . '</form><br>';

    $output .= '<table class="wub_table_striped">'
        .  '<tr><td valign="top" class="wub_settings_description">'
        .  'Select Game'
        .  '</td><td valign="top" class="wub_settings_values">'
        .  (($games->GameCount() > 0) ? $games_dropdown : '')
        .  '</td></tr>';

    $output .=   wub_serials_settings( $gid );
    $output .=  '</table>';

    return $output;

}

function wub_serials_settings($gid)
{
    //see if we just did a search for a user
    if (isset($_POST['wub_serial_action']))
    {
	    $uid = Postedi('uid');
        switch ($_POST['wub_serial_action'])
        {
            case 'Search':
                $users = new WubUsers();
                $user = $users->GetSingleUserByName($_POST['wub_find_user']);
                if ($user > 0) {
                    $_POST['uid'] = $user;
                    $_REQUEST['uid'] = $user;
                }
                break;

            case 'Generate':
                $serial_object = new WubSerials($gid, 0);
                $serial_object->GenerateSerials(Postedi('qty'), Postedi('reserved'));
                break;

	        case "Allocate":
		        if (!($uid == 0 || $gid == 0)) {
			        $serial_object = new WubSerials($gid, $uid);
			        $serial_object->LicenseGameToUser();
		        };
	        	break;

	        case "Remove":
	        case 'Revoke Serial':
	        	$serial = Posted('serial');
	        	if ($serial != '') {
			        $serial_object = new WubSerials($gid, $uid);
			        $serial_object->RemoveRegistration($serial);
		        }
	        	break;
        }
    }

	$button_values = array("Overview","Game Data","User Data");

    $output = '
        <tr><td colspan="2">
        <form method="post"><input type="hidden" name="menu_tab" value="'.MENUTAB.'">';
    foreach ($button_values as $button_value)
        $output .= '<input type="'.(MENUSUB == $button_value ? 'button' : 'submit')
	            . '" name="menu_sub" value="'.$button_value
	            . '" class="button-'.(MENUSUB == $button_value ? 'primary' : 'secondary').'">';
	$output .= "<input type=hidden name=gid value=\"$gid\">";
    $output .= '</form></td></tr>';

    switch(MENUSUB)
    {
        case "Overview": $output .= draw_settings_overview($gid); break;
        case "Game Data": $output .= draw_settings_game_data($gid); break;
        case "User Data": $output .= draw_settings_userdata($gid); break;
    }

    return $output;
}

function draw_settings_overview($gid)
{
    global $wpdb;
	$available = $wpdb->get_var("SELECT COUNT(*) FROM ".wub_prefix."serials WHERE gid='$gid' AND uid='0' AND reserved='0'");
	$used = $wpdb->get_var("SELECT COUNT(*) FROM ".wub_prefix."serials WHERE gid='$gid' AND uid <> '0' AND reserved='0'");
	$available_reserved = $wpdb->get_var("SELECT COUNT(*) FROM ".wub_prefix."serials WHERE gid='$gid' AND uid='0' AND reserved='1'");
	$used_reserved = $wpdb->get_var("SELECT COUNT(*) FROM ".wub_prefix."serials WHERE gid='$gid' AND uid <> '0' AND reserved='1'");

    $output = '
        <tr><td valign="top" class="wub_settings_description" style="width:235px;">Basic Stats</td>
        <td valign="top" class="wub_settings_values" id="basic_stats" style="width:632px">
        <strong>Normal serials</strong><br>Available serials: '.$available.'<br>Allocated serials: '.$used.'<p>
        <strong>Reserved serials</strong><br>Available serials: '.$available_reserved.'<br>Allocated serials: '.$used_reserved.'</p>
        </td></tr>
        <tr><td valign="top" class="wub_settings_description">Generate Serials</td>
        <td valign="top" class="wub_settings_values"><form method="post">
        <input type=hidden name="menu_tab" value="' . MENUTAB . '">
        <input type=hidden name="gid" value="'.$gid.'">
        QTY:<input style="margin:0px 10px;" type=number min="1" max="500" size="3" name="qty">
        <input type="submit" class="button-secondary inputbutton" name="wub_serial_action" value="Generate">
        <input type="checkbox" style="padding-left: 25px" name="reserved" value=1> Reserved for manual distribution
        </form>
        </td></tr>
        ';
    return $output;
}

function draw_settings_game_data($gid)
{
    global $wpdb;
    $serials_table = wub_prefix ."serials";
    $users_table = $wpdb->users;
	$action_list = array("View Available", "View Allocated", "View Reserved", "View Allocated Reserved", "Delete Unallocated", "Delete Unallocated Reserved");

	if (!isset($_REQUEST['menu_subsub']))
		$_REQUEST['menu_subsub'] = $action_list[0];
	define('MENUSUBSUB', $_REQUEST['menu_subsub']);

	$reserved = strpos($_REQUEST['menu_subsub'],"Reserved") > 0 ? 1 : 0;
	$query_view_used = "
		SELECT {$serials_table}.serial, {$users_table}.user_login 
	    FROM $serials_table
   		INNER JOIN $users_table ON {$serials_table}.uid = {$users_table}.ID
    	WHERE gid = '$gid' AND uid <> '0' AND reserved = '$reserved'
   		";

	$query_view_available = "SELECT serial from $serials_table WHERE uid='0' AND gid='$gid' AND reserved='$reserved'";
    $query_free_serials = "DELETE FROM $serials_table WHERE gid='$gid' AND uid='0' AND reserved='$reserved'";

    $query = $query_view_available;
    switch(MENUSUBSUB)
    {
	    case 'View Allocated':
	    case 'View Allocated Reserved':
            $query = $query_view_used;
            break;

        case 'Delete Unallocated':
	    case 'Delete Unallocated Reserved':
            $wpdb->query($query_free_serials);
            break;
    }

    $serials = $wpdb->get_results($query);
    if (!$serials)
        $right_side = '<div class="stattable">No serials found</div>';
    else
    {
        $right_side = '<table class="stattable" style="padding:10px;">';
        if (MENUSUBSUB == 'View Allocated' || MENUSUBSUB == 'View Allocated Reserved') :
            $right_side .= '<tr class=stattableheader><td style="padding-left: 15px; width:250px;">Serial</td><td colspan=2 style="padding-left: 15px; width:250px;">Owner</td></tr>';
            foreach($serials as $entry)
                $right_side .= "
					<tr>
					<td style=\"padding-left: 15px; border:1px solid;\">$entry->serial</td>
					<td style=\"padding-left: 15px; border:1px solid;\" class=inputfield>$entry->user_login</td>
					<td align=right><form method=post>
					<input type=hidden name=menu_tab value=\"".MENUTAB."\">
					<input type=hidden name=menu_sub value=\"".MENUSUB."\">
					<input type=hidden name=menu_subsub value=\"".MENUSUBSUB."\">
					<input type=hidden name=gid value=\"$gid\">
					<input type=hidden name=serial value=\"$entry->serial\">
					<input type=submit name=wub_serial_action value=\"Revoke Serial\">
					</form>
					</td>
					</tr>";
        else:
            $left = true;
            $right_side .= '<tr style="border: 1px solid red;"><td colspan=2 class=stattableheader>Available Serials</td></tr>';
            foreach($serials as $entry) {
             if ($left)
                $right_side .= "<tr><td style=\"padding:0px 50px 0px 15px;width:50%; border: 1px solid;\">$entry->serial</td>";
             else
                 $right_side .= "<td style=\"padding:0px 15px;width:50%; border: 1px solid;\">$entry->serial</td></tr>";
             $left = !$left;
            }
            if(!$left)
                $right_side .= "<td>&nbsp;</td></tr>";
        endif;
        $right_side .= '</table>';
    }

    $output = '<tr><td valign="top" class="wub_settings_description">';
    foreach($action_list as $action) {
	    $output .= '
			<form method="POST"><input type=' . (MENUSUBSUB == $action ? 'button' : 'submit') .
		    ' name="menu_subsub" value="' . $action .
		    '" style="width:200px;" class="button-' . (MENUSUBSUB == $action ? 'secondary' : 'primary') . '">
        <input type="hidden" name="menu_tab" value="' . MENUTAB . '">
        <input type="hidden" name="menu_sub" value="' . MENUSUB . '">
        <input type="hidden" name="gid" value="' . $gid . '">
        </form>';
    }
    $output .= '
        </td>
        <td valign="top" class="wub_settings_values">'
        .$right_side.'
        </td></tr>
        ';
    return $output;
}

function draw_settings_userdata($gid)
{
    global $wpdb;
    $table = wub_prefix.'serials';
    $uid = Postedi("uid");
    $users_obj = new WubUsers($gid);

    $wub_users_list = '
		<table><tr><td>
        <form method="POST">
		<input type="hidden" name="menu_tab" value="'.MENUTAB.'">
		<input type="hidden" name="menu_sub" value="'.MENUSUB.'">
		<input type="hidden" name="gid" value="'.$gid.'">'
        . $users_obj->DropDownList($gid, $uid, Posted('ufilter'))
        . $users_obj->FilterDropDown(Posted('ufilter')) .'
        </form>
        </td><td>'
        . UserSearchField($gid, array('menu_sub' => MENUSUB)) .'
        </td></tr></table>';

    $serial_query = "SELECT serial FROM $table WHERE gid='$gid' AND uid='$uid'";
    $serial = $wpdb->get_var($serial_query);

    $serials_table = wub_prefix . 'serials';
    $posts_table = $wpdb->posts;
	$all_serials_query = "
            SELECT {$serials_table}.serial, {$serials_table}.gid, {$posts_table}.post_title
            FROM $serials_table
            LEFT JOIN $posts_table ON {$serials_table}.gid = {$posts_table}.ID
            WHERE {$serials_table}.uid = '$uid'";

    $right_side = "<div class=\"wub_settings_values\" style=\"width:632px\">";
    $all_serials = $wpdb->get_results($all_serials_query);
    if (!$all_serials) :
    	$right_side .= "No serials found</div>";
    else:
    	$right_side = '
		<table class="wub_settings_values" style="width:590px;">
		<tr class=stattableheader><td style="padding-left:15px;">Game</td><td style="padding-left:15px;">Serial</td><td>&nbsp;</td></tr>';
    	foreach($all_serials as $entry)
	    {
	    	$right_side .= "<tr><td class=wub_settings_values>$entry->post_title</td><td class=wub_settings_values>$entry->serial</td>
			<td class=wub_settings_values style=\"width:40px;\">
			<form method=post>
			<input type=hidden name=menu_tab value=\"".MENUTAB."\">
			<input type=hidden name=menu_sub value=\"".MENUSUB."\">
			<input type=hidden name=serial value=\"".$entry->serial."\">
			<input type=hidden name=uid value=\"".$uid."\">
			<input type=hidden name=gid value=\"".$gid."\">
			<input type=submit name=wub_serial_action value=\"Revoke Serial\">
			</form>
			</td>
			";
	    }
	    $right_side .= '</table></form>';
    endif;

    $output = '
        <tr><td valign="top" class="wub_settings_description" style="width:235px">
        Select Account Holder
        </td><td valign="top" class="wub_settings_values" style="width:632px">'.
        $wub_users_list .'
        </td></tr>

        <tr><td class="wub_settings_description">Allocated serial</td>
        <td class="wub_settings_values">';
    if (null === $serial) :
		$output  .= '
        <form method="post"><input type="hidden" name="menu_tab" value="'.MENUTAB.'">
        <input type="hidden" name="menu_sub" value="'.MENUSUB.'">
        <input type="hidden" name="uid" value="'.$uid.'">
        <input type="submit" method="post" style="width:75px" name="wub_serial_action" value="Allocate">';
    else:
        $output .= '<div style="padding-left:10px;">'.$serial.'</div>';
	endif;
    $output .= '
        </form></td></tr>
        <tr><td class="wub_settings_description">All serials</td>
        <td class="wub_settings_values">'.
        $right_side .'
        </td></tr>'
        ;

    return $output;
}

function UserSearchField($gid, $hidden)
{
    $output = "<form method=POST>"
            ."<input type='text' name='wub_find_user'>"
            . "<input type='submit' class='button-secondary inputbutton' name='wub_serial_action' value='Search'>"
            . '<input type="hidden" name="gid" value="' . $gid . '">'
            . '<input type="hidden" name="menu_tab" value="' . MENUTAB . '">';
    foreach($hidden as $name => $value)
        $output .= "<input type=hidden name=$name value=\"$value\">";
    $output . "</form>";
    return $output;
}
