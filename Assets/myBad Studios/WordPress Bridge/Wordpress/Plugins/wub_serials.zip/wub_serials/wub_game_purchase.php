<?php
add_action( 'wub_purchase', 'wub_game_purchase' );

function wub_game_purchase($args)
{
	//if the type of this transaction is not "game"
	//then this transaction was not meant for this plugin so quit
	if( $args['type'] != "game" )
		return;

	$uid = intval($args['uid']);
	$gid = intval($args['gid']);

	$serials = new WubSerials($gid, $uid);
	$serials->LicenseGameToUser();
}
