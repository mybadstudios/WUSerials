<?php		
include_once(dirname(__FILE__) . "/../wub_login/functions.php");
include_once("Settings/wub_serials.php");

add_filter("wub_section_heading", "wub_add_serials_menu",23,2);
add_filter("wub_section_content", "wub_show_serials_section", 25, 2);

function wub_add_serials_menu($value)
{
    $menu_button = new WubMenuItem('Serials');
    return $value . $menu_button->GenerateMenuButton();
}

function wub_show_serials_section($content, $test)
{
    return (MENUTAB == SERIALS_CONSTANT) ? show_wub_serials_content() : $content;
}
